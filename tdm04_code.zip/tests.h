#pragma once

double* initialize_array(double* array, int n);
int test_tableau_dynamique(double* array, int n);
int test_liste(double* array, int n);
int test_tri_fusion_1(double* array, int n);
int test_tri_fusion_2(double* array, int n);
int test_tri_rapide(double* array, int n);
int test_lstbl(double* array, int n);
int test_liste_fin_1(double* array, int n);
int test_liste_fin_2(double* array, int n);

